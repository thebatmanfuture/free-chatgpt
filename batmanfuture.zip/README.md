作者github：https://github.com/thebatmanfuture

作者博客：https://batmanfuture.cn/

联系qq：1601749085

### python实现获取免费的chatgpt

fofa搜索

~~~http
title="ChatGPT Web"
~~~

[![p9xZRAg.png](https://s1.ax1x.com/2023/05/31/p9xZRAg.png)](https://imgse.com/i/p9xZRAg)

这个是由于这个项目的未授权导致的，https://github.com/Chanzhaoyu/chatgpt-web

urls.txt放你得到的url

[![p9xmWSs.png](https://s1.ax1x.com/2023/05/31/p9xmWSs.png)](https://imgse.com/i/p9xmWSs)

运行

[![p9xmhyq.png](https://s1.ax1x.com/2023/05/31/p9xmhyq.png)](https://imgse.com/i/p9xmhyq)

打开

[![p9xmOp9.png](https://s1.ax1x.com/2023/05/31/p9xmOp9.png)](https://imgse.com/i/p9xmOp9)

.























